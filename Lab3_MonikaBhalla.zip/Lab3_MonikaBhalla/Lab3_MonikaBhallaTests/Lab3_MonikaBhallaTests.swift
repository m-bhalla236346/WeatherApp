//
//  Lab3_MonikaBhallaTests.swift
//  Lab3_MonikaBhallaTests
//
//  Created by MONIKA BHALLA  on 2024-11-04.
//

import Testing
@testable import Lab3_MonikaBhalla

struct Lab3_MonikaBhallaTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
